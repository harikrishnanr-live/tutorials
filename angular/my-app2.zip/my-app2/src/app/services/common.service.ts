import { Injectable } from '@angular/core';
import { WebapiService } from './webapi.service';
import { Observable } from 'rxjs';

var apiUrl = "http://restapi.adequateshop.com/api/";

var httpLink = {
  loginapi: apiUrl + "authaccount/registration",
  signupapi: apiUrl+ "authaccount/registration"
}

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private webApiService: WebapiService) { }

  public login(model: any): Observable<any> {
    return this.webApiService.postData(httpLink.loginapi, model);
  }  

  public signup(model: any): Observable<any> {
    return this.webApiService.postData(httpLink.signupapi, model);
  }  
}
