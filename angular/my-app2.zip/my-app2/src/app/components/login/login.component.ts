import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { CommonService } from '../../services/common.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  userLoginForm!: FormGroup;
  userLoginPage: any = {
    useremail: '',
    userpassword: ''
  };
  sendData: any;

  constructor(private httpProvider: CommonService,
    private formbuilder: FormBuilder
  ) {
    this.userLoginForm = this.formbuilder.group({
      useremail: new FormControl(),
      userpassword: new FormControl()
    });
  }

  onLogin(userData: any){
    this.sendData = {
      useremail: userData.useremail,
      userpassword: userData.userpassword
    }
    this.httpProvider.login(this.sendData).subscribe(
      result => {
        console.log(result)
        return result;
      },
      error => {
        console.log(error);
        return error;
      }
    );
  }

}
