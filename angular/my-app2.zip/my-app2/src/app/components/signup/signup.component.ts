import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { CommonService } from '../../services/common.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})
export class SignupComponent {

  userSignUpForm!: FormGroup;
  userSignUpPage: any = {
    username: '',
    useremail: '',
    userpassword: ''
  };
  sendData: any;

  constructor(private httpProvider: CommonService,
    private formbuilder: FormBuilder
  ) {
    this.userSignUpForm = this.formbuilder.group({
      username: new FormControl(),
      useremail: new FormControl(),
      userpassword: new FormControl()
    });
  }

  onSignup(userData: any){
    this.sendData = {
      username: userData.username,
      useremail: userData.useremail,
      userpassword: userData.userpassword
    }
    this.httpProvider.signup(this.sendData).subscribe(
      result => {
        console.log(result)
        return result;
      },
      error => {
        console.log(error);
        return error;
      }
    );
  }

}
